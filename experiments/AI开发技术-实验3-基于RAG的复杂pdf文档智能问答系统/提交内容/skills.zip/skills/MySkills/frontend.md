---
name: frontend
description: Streamlit frontend development patterns for RAG-based Q&A systems with API config and PDF upload
---

# 前端Skill — Streamlit界面开发

## 页面布局

使用 `st.set_page_config` 设置宽屏布局：
```python
st.set_page_config(
    page_title="PDF 智能问答系统",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)
```

整体结构：左侧侧边栏（设置/状态）+ 右侧主聊天区域。

## 侧边栏（Sidebar）设计

按以下顺序组织侧边栏内容：

### 1. API设置区域
- API Key 输入框 (`st.text_input`, type="password")
- Base URL 输入框
- 模型选择下拉框 (`st.selectbox`: deepseek-chat / deepseek-reasoner)
- "更新API"按钮 + "恢复默认"按钮并排

### 2. PDF上传区域
- `st.file_uploader` (type=["pdf"])
- 上传后保存到 `data/` 目录
- 提示用户运行 `build_kb.py` 重建知识库

### 3. 数据库状态区域
- 实时显示各集合向量数量（如 "文本: 67条, 图片: 59条"）
- 使用 `st.metric` 组件

### 4. 系统信息区域
- Embedding模型名称
- 当前PDF文件名
- 总页数、向量维度

## 配置管理

使用 `st.session_state` 管理运行时配置（支持动态更新API Key而无需重启）：

```python
class AppConfig:
    @staticmethod
    def get(key, default=""):
        return st.session_state.get(f"cfg_{key}", os.getenv(key, default))

    @staticmethod
    def set(key, value):
        st.session_state[f"cfg_{key}"] = value
        os.environ[key] = value

    @staticmethod
    def init_defaults():
        # 从 .env 读取默认值写入 session_state
        defaults = ["DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", "DEEPSEEK_MODEL",
                     "EMBEDDING_MODEL", "PDF_PATH", "MILVUS_DB_PATH"]
        for k in defaults:
            if f"cfg_{k}" not in st.session_state:
                st.session_state[f"cfg_{k}"] = os.getenv(k, "")
```

## 资源缓存

使用 `st.cache_resource` 避免重复加载模型：

```python
@st.cache_resource
def get_embedding_engine():
    # 加载 Embedding 模型（只加载一次，全局复用）

def get_milvus_client():
    # 获取 Milvus 客户端（每次连接后 load_collection）
```

注意：**不要**对 `get_milvus_client` 使用 `st.cache_resource`，因为它需要在每次请求时重新 `load_collection`。对LLM也要用 `st.cache_resource` 清理机制配合 API Key 更新。

## 连接检测

启动时检查两个连接状态并在主页面顶部显示：

```python
def check_api_connection():
    # 用 OpenAI SDK 发一个简短测试请求
    # 返回 (bool, "状态描述")

def check_db_connection():
    # 检查 Milvus 集合是否存在且包含数据
    # 返回 (bool, "状态描述", {"text": n, "image": m})
```

状态显示：绿色 `st.success` / 红色 `st.error` / 黄色 `st.warning`

## 聊天界面

使用 Streamlit 原生聊天组件：
```python
# 初始化消息历史
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "欢迎消息..."}
    ]

# 显示历史消息
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# 输入框
if prompt := st.chat_input("请输入您的问题..."):
    # 1. 添加用户消息
    # 2. 检索相关上下文
    # 3. 调用LLM生成回答
    # 4. 添加助手消息（含参考来源）
```

## 参考来源展示

每条助手回答附带可展开的参考来源：
```python
with st.expander("📎 参考来源"):
    for src in sources:
        st.caption(f"[{src['type']}] 第{src['page']}页 (相似度: {src['score']:.3f})")
        st.text(src["text"][:300])
```

## 错误处理

针对不同失败模式给出明确的错误提示：

| 场景 | 提示信息 |
|------|---------|
| API Key未设置 | "请先设置 DeepSeek API Key" |
| API Key无效 | "API Key 无效或已过期，请在侧边栏更新" |
| 知识库为空 | "数据库为空，请先运行 build_kb.py 构建知识库" |
| 检索无结果 | "未检索到相关内容。可能原因：1) 知识库未构建 2) 问题与文档无关 3) 请尝试换一种问法" |
| API频率超限 | "API 调用频率超限，请稍后重试" |
| Milvus连接失败 | "数据库连接失败，请检查 milvus.db 路径" |

## 底部操作按钮

- "清空对话" — 重置聊天历史
- "刷新状态" — 清除缓存并重新检测连接
- "使用帮助" — 显示使用说明

## 注意事项

- 项目根目录通过 `Path(__file__).resolve().parent.parent` 获取（因为脚本在 SkillVersion/ 子目录下）
- `.env` 文件在项目根目录，用 `load_dotenv(PROJECT_ROOT / ".env")` 加载
- 确保 PDF 路径、Milvus 路径都相对于项目根目录
