---
name: pdf-parser
description: PDF structure parsing, text extraction, table extraction, image/chart extraction with OCR for Chinese financial PDFs
---

# PDF解析Skill — 中文金融PDF文档解析

## 核心原则

1. **必须使用 PyMuPDF (fitz) 作为主文本提取引擎**。pdfplumber 对中文内嵌字体编码支持有问题，提取文本会产生乱码。只对纯英文PDF才考虑 pdfplumber 作为备选。
2. PyMuPDF 的 `page.get_text("text")` 已经将表格内容包含在页面文本中，因此不需要单独用 `find_tables()` 提取表格（`find_tables()` 在该类中文PDF上同样存在编码问题）。
3. 图片OCR使用 EasyOCR，中英文混合识别。
4. 必须清洗页眉页脚等重复噪声文本。

## PDF文本提取

```python
import fitz  # PyMuPDF

doc = fitz.open(pdf_path)
page = doc[page_num]
text = page.get_text("text")
```

提取后需要清洗以下类型的噪声行：
- 固定的页眉声明："敬请阅读最后一页特别声明"
- 栏目名称："证券研究报告"、"金融工程"
- 页码标记：如 "-6-"、"-10-" 等短横线包围的数字
- 空行

清洗代码模式：
```python
lines = text.strip().split("\n")
cleaned = []
for line in lines:
    s = line.strip()
    if s in ("", "敬请阅读最后一页特别声明"):
        continue
    if s.startswith("证券研究报告") or s.startswith("金融工程"):
        continue
    if s.startswith("-") and s.endswith("-") and len(s) <= 5:
        continue  # 页码
    cleaned.append(line)
return "\n".join(cleaned).strip()
```

## 图片提取与OCR

使用 PyMuPDF 提取图片：
```python
page.get_images(full=True)  # 获取所有图片的xref列表
doc.extract_image(xref)      # 提取单张图片
```

过滤条件：
- 跳过宽度和高度均小于100px的图片（通常是图标/装饰元素）
- 保存到 `data/images/` 目录，文件名包含页码和MD5哈希

OCR配置：
```python
import easyocr
reader = easyocr.Reader(["ch_sim", "en"], gpu=False, verbose=False)
results = reader.readtext(image_np)
texts = [r[1] for r in results if r[2] >= 0.3]  # 置信度阈值0.3
ocr_text = " ".join(texts)
```

生成的图片描述格式：
```
"[图片] 位于第 {page} 页；尺寸: {width}x{height}；OCR 识别文字: {ocr_text}"
```

如果OCR无结果：
```
"[图片] 位于第 {page} 页；尺寸: {width}x{height}；(该图片无可识别文字，可能为纯图表)"
```

## 输出格式

文本解析返回 `text_docs`，图片解析返回 `image_docs`：

```python
text_doc = {
    "text": "页面文本内容...",
    "metadata": {
        "page": 1,         # 页码（从1开始）
        "type": "text",
        "source": "金融研报.pdf"
    }
}

image_doc = {
    "text": "[图片] 位于第3页；OCR识别文字: ...",
    "metadata": {
        "page": 3,
        "type": "image",
        "image_path": "data/images/p3_img0_abc123.png",
        "filename": "p3_img0_abc123.png",
        "ocr_text": "原始OCR文字",
        "width": 800,
        "height": 600,
        "source": "金融研报.pdf"
    }
}
```

## 注意事项

- 金融PDF中的图表（折线图、柱状图、PE对比图）包含的轴标签、图例文字可以被OCR部分恢复
- 不要在PDF解析阶段对表格做Markdown转换——表格文字已包含在页面文本中，LLM可以直接理解
- EasyOCR首次运行会下载模型文件（~100MB），国内网络可能需要设置镜像
