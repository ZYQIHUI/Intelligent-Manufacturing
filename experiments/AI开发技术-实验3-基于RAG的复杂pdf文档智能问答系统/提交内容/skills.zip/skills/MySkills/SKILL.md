---
name: MySkills
description: 基于RAG的复杂PDF文档智能问答系统 — 包含前端界面、PDF解析、RAG检索生成、向量数据库四大技能模块
---

# 基于RAG的复杂PDF文档智能问答系统 — 技能集

本目录包含四个子技能，覆盖了从PDF文档解析到RAG智能问答的完整技术栈。适用于中文金融研报等复杂PDF文档的智能问答场景。

## 技能概览

| 技能文件 | 技能名称 | 功能说明 |
|----------|---------|---------|
| `frontend.md` | 前端界面 | Streamlit 驱动的 Web 交互界面：API 配置管理、PDF 上传、知识库状态监控、聊天问答、参考来源展示 |
| `pdf-parser.md` | PDF 文档解析 | 中文金融 PDF 解析引擎：PyMuPDF 文本提取 + EasyOCR 图片识别、页眉页脚清洗、结构化输出 |
| `rag-system.md` | RAG 检索生成 | 基于 LlamaIndex + DeepSeek 的检索增强生成：文本分块、跨集合均衡采样检索、结构化 Prompt |
| `vector-db.md` | 向量数据库 | Milvus Lite 嵌入式向量库：双集合设计（文本+图片）、向量化插入、余弦相似度搜索 |

## 技术栈

- **前端**: Streamlit
- **PDF解析**: PyMuPDF (fitz), EasyOCR
- **RAG框架**: LlamaIndex
- **LLM**: DeepSeek-Chat (OpenAI 兼容 API)
- **Embedding**: BAAI/bge-small-zh-v1.5 (512维)
- **向量数据库**: Milvus Lite (嵌入式)
- **语言**: Python

## 工作流程

1. **PDF解析** (`pdf-parser.md`) → 提取文本 + 图片OCR
2. **文本分块** (`rag-system.md`) → SentenceSplitter 切分
3. **向量入库** (`vector-db.md`) → Embedding + Milvus 双集合存储
4. **用户提问** (`frontend.md`) → 跨集合检索 → LLM 生成回答 → 展示来源

## 适用场景

- 金融研报、年报、招股书等复杂 PDF 的知识问答
- 需要同时检索文字内容与图表信息的多模态场景
- 小规模（<1000 页）本地化部署的 RAG 应用

## 注意事项

- 各技能文件按顺序阅读效果更佳：从 PDF 解析 → 向量存储 → RAG 检索 → 前端展示
- 所有技能都针对中文金融 PDF 场景做了专门优化（编码处理、OCR 配置、检索策略）
- 如需了解具体 API 配置或运行方式，请参考各技能文件中的代码示例
