---
name: rag-system
description: RAG retrieval, augmentation, and generation using LlamaIndex + DeepSeek for Chinese financial Q&A
---

# RAG系统Skill — 检索增强生成系统

## 核心组件

- **Embedding**: BAAI/bge-small-zh-v1.5 (512维, 中文金融文本优化, 首次自动下载)
- **LLM**: DeepSeek-Chat (通过 OpenAI 兼容 API, base_url=https://api.deepseek.com)
- **文本分块**: LlamaIndex SentenceSplitter

## 文本分块（关键！）

整页文本直接向量化会导致语义稀释，必须分块。使用 LlamaIndex SentenceSplitter：

```python
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core import Document as LDocument

splitter = SentenceSplitter(
    chunk_size=512,   # 每块最多512字符
    chunk_overlap=50, # 块之间有50字符重叠，防止语义在边界被切断
)

# 将 text_docs 转为 LlamaIndex Document 再分块
for d in text_docs:
    nodes = splitter.get_nodes_from_documents([
        LDocument(text=d["text"], metadata=d["metadata"])
    ])
    for node in nodes:
        chunked_text_docs.append({
            "text": node.text,
            "metadata": {**d["metadata"], "chunk_size": len(node.text)},
        })
```

## 跨集合检索策略（关键！）

图片OCR向量在相似度搜索时分数系统性偏高（因为OCR文本碎片化、关键词密度大），不能用简单的按分数混合排序。必须使用**均衡采样策略**：

- 文本集合：取 `top_k` 条（推荐8条）
- 图片集合：取 `top_k // 2` 条（推荐4条）
- 合并时文本结果放在前面，图片结果放后面
- 不要按分数对两类结果进行混合排序

```python
def search_all_collections(client, embed_engine, query, top_k=8):
    query_emb = embed_engine.get_text_embedding(query)

    text_results = search_col("text_collection", query_emb, limit=top_k)
    image_results = search_col("image_collection", query_emb, limit=max(2, top_k // 2))

    # 去重合并：文本在前，图片在后
    seen = set()
    merged = []
    for r in text_results:
        key = r["text"][:100]
        if key not in seen:
            seen.add(key)
            merged.append(r)
    for r in image_results:
        key = r["text"][:100]
        if key not in seen:
            seen.add(key)
            merged.append(r)
    return merged
```

## Prompt 模板

提供检索到的上下文后，用以下结构化Prompt让LLM生成回答：

```
你是一个专业的金融研报分析助手。请根据以下从PDF文档中检索到的信息，准确回答用户的问题。

## 规则
- 如果检索信息足以回答问题，请给出准确、详细的答案。
- 如果涉及数据，必须给出具体数值。
- 如果检索信息不足以回答问题，请明确说明原因。
- 用中文回答，保持专业。

## 检索信息
[来源1] 类型: 文本 | 页码: 5
...

## 用户问题
...

## 回答
```

## DeepSeek API 调用

使用 LlamaIndex 的 OpenAILike 封装：
```python
from llama_index.llms.openai_like import OpenAILike

llm = OpenAILike(
    model="deepseek-chat",
    api_base="https://api.deepseek.com",
    api_key=os.getenv("DEEPSEEK_API_KEY"),
    is_chat_model=True,
    max_tokens=2048,
    temperature=0.3,    # 低温度保证回答准确性
)
resp = llm.complete(prompt)
answer = resp.text.strip()
```

温度参数说明：对于金融数据查询任务，temperature=0.1~0.3 最合适。太高会导致数值不准确。

## Embedding 模型加载

```python
from llama_index.embeddings.huggingface import HuggingFaceEmbedding

embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-small-zh-v1.5",
    max_length=512,
    trust_remote_code=True,
)
# 获取向量维度
dim = len(embed_model.get_text_embedding("test"))  # 结果为 512
```

## 注意事项

- 检索结果为空时，给用户明确的提示：知识库未构建、问题与文档无关、或建议换种问法
- 不要在检索阶段做复杂的rerank——对于~100条向量的规模，均衡采样策略已经足够
- 每次检索时保持 low temperature (0.1-0.3) 以保证数据准确性
