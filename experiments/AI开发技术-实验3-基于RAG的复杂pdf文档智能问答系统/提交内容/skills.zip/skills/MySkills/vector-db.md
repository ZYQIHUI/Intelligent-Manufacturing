---
name: vector-db
description: Milvus Lite vector database configuration, collection management, and search for RAG applications
---

# 向量数据库Skill — Milvus Lite 配置与操作

## Milvus Lite 概述

Milvus Lite 是嵌入式向量数据库，数据存储为本地文件（`milvus.db`），无需服务端进程。适合小规模RAG应用（<100万向量）。

## 连接

```python
from pymilvus import MilvusClient
from pathlib import Path

db_path = "./data/milvus.db"
Path(db_path).parent.mkdir(parents=True, exist_ok=True)
client = MilvusClient(str(db_path))
```

## 集合设计

由于PyMuPDF的 `page.get_text()` 已将表格内容包含在文本中，只使用两个集合：

| 集合名 | 内容 | 说明 |
|--------|------|------|
| `text_collection` | 文本分块后的向量 | 主要检索源 |
| `image_collection` | 图片OCR描述的向量 | 辅助检索源 |

不使用单独的 table_collection（表格已包含在文本中）。

## 创建集合

```python
# 先删除旧集合（重建时）
for name in ["text_collection", "image_collection"]:
    if client.has_collection(name):
        client.drop_collection(name)
    client.create_collection(
        collection_name=name,
        dimension=512,            # bge-small-zh-v1.5 输出512维
        metric_type="COSINE",     # 语义相似度用余弦距离
    )
```

## 数据插入与加载（关键！）

**Milvus Lite在连接断开后集合会自动释放内存（released状态）**。必须在插入后和每次连接后手动load：

```python
# 插入时每条记录包含：id, vector, text, page, type, metadata_json
data = [{
    "id": i,
    "vector": embedding,           # List[float], 512维
    "text": doc["text"],           # 文本内容
    "page": doc["metadata"]["page"],
    "type": doc["metadata"]["type"],
    "metadata_json": json.dumps(doc["metadata"], ensure_ascii=False),
} for i, doc in enumerate(docs)]

client.insert(collection_name=collection_name, data=data)

# 必须立即加载到内存！
client.load_collection(collection_name)
```

**在app.py中每次连接时也必须在搜索前加载：**
```python
for col in ["text_collection", "image_collection"]:
    if client.has_collection(col):
        try:
            client.load_collection(col)
        except Exception:
            pass  # 可能已加载
```

## 搜索

```python
results = client.search(
    collection_name=collection_name,
    data=[query_embedding],         # 注意是列表的列表
    limit=top_k,
    output_fields=["text", "page", "type", "metadata_json"],
)

# 结果解析
hits = []
for r in results[0]:
    entity = r.get("entity", {})
    hits.append({
        "score": r.get("distance", 0),
        "text": entity.get("text", ""),
        "page": entity.get("page", 0),
        "type": entity.get("type", ""),
        "metadata": json.loads(entity.get("metadata_json", "{}")),
    })
```

## 统计信息

```python
stats = client.get_collection_stats(collection_name)
row_count = stats.get("row_count", 0)
```

## 注意事项

- `create_collection` 时 dimension 必须与实际向量维度一致（bge-small=512）
- FLAT索引足够——对于~100-1000条向量的规模，暴力搜索精度最高且速度完全够用
- `milvus.db` 路径建议放在项目 `data/` 目录下，通过 `.env` 配置
- 搜索时 `limit` 不能超过集合中的向量总数
